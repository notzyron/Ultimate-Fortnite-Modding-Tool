#include "PhysicsImporter.h"

#include "Dom/JsonObject.h"
#include "Serialization/JsonReader.h"
#include "Serialization/JsonSerializer.h"
#include "PhysicsEngine/PhysicsAsset.h"
#include "PhysicsEngine/PhysicsConstraintTemplate.h"
#include "PhysicsEngine/ConstraintInstance.h"
#include "PhysicsEngine/ConstraintTypes.h"
#include "AssetRegistryModule.h"
#include "Engine/SkeletalMesh.h"
#include "AnimGraphNode_CopyPoseFromMesh.h"
#include "AnimGraphNode_LocalToComponentSpace.h"
#include "AnimGraphNode_ComponentToLocalSpace.h"
#include "AnimGraphNode_RigidBody.h"
#include "AnimGraphNode_Root.h"
#include "AnimationGraphSchema.h"
#include "EdGraphSchema_K2.h"
#include "Kismet2/BlueprintEditorUtils.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "Animation/AnimBlueprint.h"
#include "Animation/AnimInstance.h"
#include "Animation/Skeleton.h"
#include "Factories/AnimBlueprintFactory.h"
#include "PackageTools.h"
#include "UObject/Package.h"
#include "EditorAssetLibrary.h"
#include "Misc/Paths.h"

DEFINE_LOG_CATEGORY_STATIC(LogPhysicsImporter, Log, All);

namespace
{
    FVector ReadVector(const TSharedPtr<FJsonObject>& Object, const FString& FieldName)
    {
        if (!Object.IsValid() || !Object->HasField(FieldName))
        {
            return FVector::ZeroVector;
        }

        const TSharedPtr<FJsonObject> VectorObject = Object->GetObjectField(FieldName);
        return FVector(
            VectorObject->GetNumberField(TEXT("X")),
            VectorObject->GetNumberField(TEXT("Y")),
            VectorObject->GetNumberField(TEXT("Z")));
    }

    FRotator ReadRotator(const TSharedPtr<FJsonObject>& Object, const FString& FieldName)
    {
        if (!Object.IsValid() || !Object->HasField(FieldName))
        {
            return FRotator::ZeroRotator;
        }

        const TSharedPtr<FJsonObject> RotatorObject = Object->GetObjectField(FieldName);
        return FRotator(
            RotatorObject->GetNumberField(TEXT("Pitch")),
            RotatorObject->GetNumberField(TEXT("Yaw")),
            RotatorObject->GetNumberField(TEXT("Roll")));
    }

    FString StripEnumPrefix(const FString& EnumString)
    {
        FString Value = EnumString;
        int32 SeparatorIndex = INDEX_NONE;
        if (Value.FindChar(TEXT(':'), SeparatorIndex))
        {
            Value = Value.Mid(SeparatorIndex + 1);
            if (Value.StartsWith(TEXT(":")))
            {
                Value = Value.Mid(1);
            }
        }
        return Value;
    }

    ECollisionEnabled::Type ParseCollisionEnabled(const FString& EnumString)
    {
        const FString Value = StripEnumPrefix(EnumString);
        if (Value == TEXT("QueryAndPhysics"))
        {
            return ECollisionEnabled::QueryAndPhysics;
        }
        if (Value == TEXT("PhysicsOnly"))
        {
            return ECollisionEnabled::PhysicsOnly;
        }
        if (Value == TEXT("QueryOnly"))
        {
            return ECollisionEnabled::QueryOnly;
        }
        return ECollisionEnabled::NoCollision;
    }

    EPhysicsType ParsePhysicsType(const FString& EnumString)
    {
        const FString Value = StripEnumPrefix(EnumString);
        if (Value == TEXT("PhysType_Simulated"))
        {
            return PhysType_Simulated;
        }
        if (Value == TEXT("PhysType_Kinematic"))
        {
            return PhysType_Kinematic;
        }
        return PhysType_Default;
    }

    ECollisionTraceFlag ParseCollisionTraceFlag(const FString& EnumString)
    {
        const FString Value = StripEnumPrefix(EnumString);
        if (Value == TEXT("CTF_UseSimpleAsComplex"))
        {
            return CTF_UseSimpleAsComplex;
        }
        if (Value == TEXT("CTF_UseComplexAsSimple"))
        {
            return CTF_UseComplexAsSimple;
        }
        if (Value == TEXT("CTF_UseDefault"))
        {
            return CTF_UseDefault;
        }
        return CTF_UseSimpleAndComplex;
    }

    EAngularConstraintMotion ParseAngularConstraintMotion(const FString& EnumString)
    {
        const FString Value = StripEnumPrefix(EnumString);
        if (Value == TEXT("ACM_Limited"))
        {
            return ACM_Limited;
        }
        if (Value == TEXT("ACM_Locked"))
        {
            return ACM_Locked;
        }
        return ACM_Free;
    }

    void DeserializeSphylElems(const TArray<TSharedPtr<FJsonValue>>& Elements, FKAggregateGeom& AggGeom)
    {
        for (const TSharedPtr<FJsonValue>& ElementValue : Elements)
        {
            const TSharedPtr<FJsonObject> ElementObject = ElementValue->AsObject();
            if (!ElementObject.IsValid())
            {
                continue;
            }

            FKSphylElem SphylElem;
            SphylElem.Center = ReadVector(ElementObject, TEXT("Center"));
            SphylElem.Rotation = ReadRotator(ElementObject, TEXT("Rotation"));
            SphylElem.Radius = ElementObject->GetNumberField(TEXT("Radius"));
            SphylElem.Length = ElementObject->GetNumberField(TEXT("Length"));
            SphylElem.RestOffset = ElementObject->GetNumberField(TEXT("RestOffset"));

            if (ElementObject->HasField(TEXT("Name")))
            {
                SphylElem.SetName(FName(*ElementObject->GetStringField(TEXT("Name"))));
            }

            AggGeom.SphylElems.Add(SphylElem);
        }
    }

    void DeserializeBoxElems(const TArray<TSharedPtr<FJsonValue>>& Elements, FKAggregateGeom& AggGeom)
    {
        for (const TSharedPtr<FJsonValue>& ElementValue : Elements)
        {
            const TSharedPtr<FJsonObject> ElementObject = ElementValue->AsObject();
            if (!ElementObject.IsValid())
            {
                continue;
            }

            FKBoxElem BoxElem;
            BoxElem.Center = ReadVector(ElementObject, TEXT("Center"));
            BoxElem.Rotation = ReadRotator(ElementObject, TEXT("Rotation"));
            BoxElem.X = ElementObject->GetNumberField(TEXT("X"));
            BoxElem.Y = ElementObject->GetNumberField(TEXT("Y"));
            BoxElem.Z = ElementObject->GetNumberField(TEXT("Z"));
            BoxElem.RestOffset = ElementObject->GetNumberField(TEXT("RestOffset"));

            if (ElementObject->HasField(TEXT("Name")))
            {
                BoxElem.SetName(FName(*ElementObject->GetStringField(TEXT("Name"))));
            }

            AggGeom.BoxElems.Add(BoxElem);
        }
    }

    void DeserializeSphereElems(const TArray<TSharedPtr<FJsonValue>>& Elements, FKAggregateGeom& AggGeom)
    {
        for (const TSharedPtr<FJsonValue>& ElementValue : Elements)
        {
            const TSharedPtr<FJsonObject> ElementObject = ElementValue->AsObject();
            if (!ElementObject.IsValid())
            {
                continue;
            }

            FKSphereElem SphereElem;
            SphereElem.Center = ReadVector(ElementObject, TEXT("Center"));
            SphereElem.Radius = ElementObject->GetNumberField(TEXT("Radius"));
            SphereElem.RestOffset = ElementObject->GetNumberField(TEXT("RestOffset"));

            if (ElementObject->HasField(TEXT("Name")))
            {
                SphereElem.SetName(FName(*ElementObject->GetStringField(TEXT("Name"))));
            }

            AggGeom.SphereElems.Add(SphereElem);
        }
    }

    void DeserializeConstraintProfile(const TSharedPtr<FJsonObject>& ProfileObject, FConstraintInstance& ConstraintInstance)
    {
        if (!ProfileObject.IsValid())
        {
            return;
        }

        if (ProfileObject->HasField(TEXT("ConeLimit")))
        {
            const TSharedPtr<FJsonObject> ConeLimitObject = ProfileObject->GetObjectField(TEXT("ConeLimit"));
            FConeConstraint& ConeLimit = ConstraintInstance.ProfileInstance.ConeLimit;

            if (ConeLimitObject->HasField(TEXT("Swing1LimitDegrees")))
            {
                ConeLimit.Swing1LimitDegrees = ConeLimitObject->GetNumberField(TEXT("Swing1LimitDegrees"));
            }
            if (ConeLimitObject->HasField(TEXT("Swing2LimitDegrees")))
            {
                ConeLimit.Swing2LimitDegrees = ConeLimitObject->GetNumberField(TEXT("Swing2LimitDegrees"));
            }
            if (ConeLimitObject->HasField(TEXT("Swing1Motion")))
            {
                ConeLimit.Swing1Motion = ParseAngularConstraintMotion(ConeLimitObject->GetStringField(TEXT("Swing1Motion")));
            }
            if (ConeLimitObject->HasField(TEXT("Swing2Motion")))
            {
                ConeLimit.Swing2Motion = ParseAngularConstraintMotion(ConeLimitObject->GetStringField(TEXT("Swing2Motion")));
            }
            if (ConeLimitObject->HasField(TEXT("Stiffness")))
            {
                ConeLimit.Stiffness = ConeLimitObject->GetNumberField(TEXT("Stiffness"));
            }
            if (ConeLimitObject->HasField(TEXT("Damping")))
            {
                ConeLimit.Damping = ConeLimitObject->GetNumberField(TEXT("Damping"));
            }
        }

        if (ProfileObject->HasField(TEXT("TwistLimit")))
        {
            const TSharedPtr<FJsonObject> TwistLimitObject = ProfileObject->GetObjectField(TEXT("TwistLimit"));
            FTwistConstraint& TwistLimit = ConstraintInstance.ProfileInstance.TwistLimit;

            if (TwistLimitObject->HasField(TEXT("TwistLimitDegrees")))
            {
                TwistLimit.TwistLimitDegrees = TwistLimitObject->GetNumberField(TEXT("TwistLimitDegrees"));
            }
            if (TwistLimitObject->HasField(TEXT("TwistMotion")))
            {
                TwistLimit.TwistMotion = ParseAngularConstraintMotion(TwistLimitObject->GetStringField(TEXT("TwistMotion")));
            }
            if (TwistLimitObject->HasField(TEXT("Stiffness")))
            {
                TwistLimit.Stiffness = TwistLimitObject->GetNumberField(TEXT("Stiffness"));
            }
            if (TwistLimitObject->HasField(TEXT("Damping")))
            {
                TwistLimit.Damping = TwistLimitObject->GetNumberField(TEXT("Damping"));
            }
        }

        if (ProfileObject->HasField(TEXT("AngularDrive")))
        {
            const TSharedPtr<FJsonObject> AngularDriveObject = ProfileObject->GetObjectField(TEXT("AngularDrive"));

            if (AngularDriveObject->HasField(TEXT("TwistDrive")))
            {
                const TSharedPtr<FJsonObject> TwistDriveObject = AngularDriveObject->GetObjectField(TEXT("TwistDrive"));
                if (TwistDriveObject->HasField(TEXT("Stiffness")))
                {
                    ConstraintInstance.ProfileInstance.AngularDrive.TwistDrive.Stiffness = TwistDriveObject->GetNumberField(TEXT("Stiffness"));
                }
            }

            if (AngularDriveObject->HasField(TEXT("SwingDrive")))
            {
                const TSharedPtr<FJsonObject> SwingDriveObject = AngularDriveObject->GetObjectField(TEXT("SwingDrive"));
                if (SwingDriveObject->HasField(TEXT("Stiffness")))
                {
                    ConstraintInstance.ProfileInstance.AngularDrive.SwingDrive.Stiffness = SwingDriveObject->GetNumberField(TEXT("Stiffness"));
                }
            }

            if (AngularDriveObject->HasField(TEXT("SlerpDrive")))
            {
                const TSharedPtr<FJsonObject> SlerpDriveObject = AngularDriveObject->GetObjectField(TEXT("SlerpDrive"));
                if (SlerpDriveObject->HasField(TEXT("Stiffness")))
                {
                    ConstraintInstance.ProfileInstance.AngularDrive.SlerpDrive.Stiffness = SlerpDriveObject->GetNumberField(TEXT("Stiffness"));
                }
                if (SlerpDriveObject->HasField(TEXT("bEnablePositionDrive")))
                {
                    ConstraintInstance.ProfileInstance.AngularDrive.SlerpDrive.bEnablePositionDrive = SlerpDriveObject->GetBoolField(TEXT("bEnablePositionDrive"));
                }
            }
        }
    }

    void DeserializeConstraintInstance(const TSharedPtr<FJsonObject>& InstanceObject, FConstraintInstance& ConstraintInstance)
    {
        if (!InstanceObject.IsValid())
        {
            return;
        }

        if (InstanceObject->HasField(TEXT("JointName")))
        {
            ConstraintInstance.JointName = FName(*InstanceObject->GetStringField(TEXT("JointName")));
        }
        if (InstanceObject->HasField(TEXT("ConstraintBone1")))
        {
            ConstraintInstance.ConstraintBone1 = FName(*InstanceObject->GetStringField(TEXT("ConstraintBone1")));
        }
        if (InstanceObject->HasField(TEXT("ConstraintBone2")))
        {
            ConstraintInstance.ConstraintBone2 = FName(*InstanceObject->GetStringField(TEXT("ConstraintBone2")));
        }

        if (InstanceObject->HasField(TEXT("Pos1")))     ConstraintInstance.Pos1 = ReadVector(InstanceObject, TEXT("Pos1"));
        if (InstanceObject->HasField(TEXT("PriAxis1"))) ConstraintInstance.PriAxis1 = ReadVector(InstanceObject, TEXT("PriAxis1"));
        if (InstanceObject->HasField(TEXT("SecAxis1"))) ConstraintInstance.SecAxis1 = ReadVector(InstanceObject, TEXT("SecAxis1"));
        if (InstanceObject->HasField(TEXT("Pos2")))     ConstraintInstance.Pos2 = ReadVector(InstanceObject, TEXT("Pos2"));
        if (InstanceObject->HasField(TEXT("PriAxis2"))) ConstraintInstance.PriAxis2 = ReadVector(InstanceObject, TEXT("PriAxis2"));
        if (InstanceObject->HasField(TEXT("SecAxis2"))) ConstraintInstance.SecAxis2 = ReadVector(InstanceObject, TEXT("SecAxis2"));

        if (InstanceObject->HasField(TEXT("ProfileInstance")))
        {
            DeserializeConstraintProfile(InstanceObject->GetObjectField(TEXT("ProfileInstance")), ConstraintInstance);
        }
    }
}

namespace
{
    UEdGraph* FindAnimGraph(UAnimBlueprint* AnimBlueprint)
    {
        for (UEdGraph* Graph : AnimBlueprint->FunctionGraphs)
        {
            if (Graph && *Graph->Schema && Graph->Schema->IsChildOf(UAnimationGraphSchema::StaticClass()))
            {
                return Graph;
            }
        }
        for (UEdGraph* Graph : AnimBlueprint->UbergraphPages)
        {
            if (Graph && *Graph->Schema && Graph->Schema->IsChildOf(UAnimationGraphSchema::StaticClass()))
            {
                return Graph;
            }
        }
        return nullptr;
    }

    UEdGraphPin* FindPosePin(UAnimGraphNode_Base* Node, EEdGraphPinDirection Direction)
    {
        if (!Node)
        {
            return nullptr;
        }

        for (UEdGraphPin* Pin : Node->Pins)
        {
            if (Pin->Direction != Direction)
            {
                continue;
            }

            UObject* SubCategoryObject = Pin->PinType.PinSubCategoryObject.Get();
            if (SubCategoryObject == FPoseLink::StaticStruct() || SubCategoryObject == FComponentSpacePoseLink::StaticStruct())
            {
                return Pin;
            }
        }

        return nullptr;
    }
}

FName UPhysicsImporter::GetExportNameOfSubobject(const FString& PackageIndex)
{
    FString Name = PackageIndex;
    FString Left, Right;
    if (Name.Split(TEXT("'"), &Left, &Right))
    {
        Name = Right;
    }
    if (Name.Split(TEXT(":"), &Left, &Right))
    {
        Name = Right;
    }
    Name = Name.Replace(TEXT("'"), TEXT(""));
    return FName(*Name);
}

TMap<FName, TSharedPtr<FJsonObject>> UPhysicsImporter::BuildExportMap(const TArray<TSharedPtr<FJsonValue>>& ExportsArray)
{
    TMap<FName, TSharedPtr<FJsonObject>> ExportMap;
    for (const TSharedPtr<FJsonValue>& ExportValue : ExportsArray)
    {
        const TSharedPtr<FJsonObject> ExportObject = ExportValue->AsObject();
        if (ExportObject.IsValid() && ExportObject->HasField(TEXT("Name")))
        {
            ExportMap.Add(FName(*ExportObject->GetStringField(TEXT("Name"))), ExportObject);
        }
    }
    return ExportMap;
}

void UPhysicsImporter::DeserializeBodySetup(const TSharedPtr<FJsonObject>& Properties, UBodySetup* BodySetup)
{
    if (!Properties.IsValid() || !BodySetup)
    {
        return;
    }

    if (Properties->HasField(TEXT("BoneName")))
    {
        BodySetup->BoneName = FName(*Properties->GetStringField(TEXT("BoneName")));
    }

    if (Properties->HasField(TEXT("PhysicsType")))
    {
        BodySetup->PhysicsType = ParsePhysicsType(Properties->GetStringField(TEXT("PhysicsType")));
    }

    if (Properties->HasField(TEXT("CollisionTraceFlag")))
    {
        BodySetup->CollisionTraceFlag = ParseCollisionTraceFlag(Properties->GetStringField(TEXT("CollisionTraceFlag")));
    }

    if (Properties->HasField(TEXT("AggGeom")))
    {
        const TSharedPtr<FJsonObject> AggGeomObject = Properties->GetObjectField(TEXT("AggGeom"));

        if (AggGeomObject->HasField(TEXT("SphylElems")))
        {
            DeserializeSphylElems(AggGeomObject->GetArrayField(TEXT("SphylElems")), BodySetup->AggGeom);
        }
        if (AggGeomObject->HasField(TEXT("BoxElems")))
        {
            DeserializeBoxElems(AggGeomObject->GetArrayField(TEXT("BoxElems")), BodySetup->AggGeom);
        }
        if (AggGeomObject->HasField(TEXT("SphereElems")))
        {
            DeserializeSphereElems(AggGeomObject->GetArrayField(TEXT("SphereElems")), BodySetup->AggGeom);
        }
    }

    if (Properties->HasField(TEXT("DefaultInstance")))
    {
        const TSharedPtr<FJsonObject> DefaultInstanceObject = Properties->GetObjectField(TEXT("DefaultInstance"));
        FBodyInstance& BodyInstance = BodySetup->DefaultInstance;

        if (DefaultInstanceObject->HasField(TEXT("MassInKgOverride")))
        {
            const float MassInKg = DefaultInstanceObject->GetNumberField(TEXT("MassInKgOverride"));
            const bool bOverrideMass = DefaultInstanceObject->HasField(TEXT("bOverrideMass"))
                ? DefaultInstanceObject->GetBoolField(TEXT("bOverrideMass"))
                : true;
            BodyInstance.SetMassOverride(MassInKg, bOverrideMass);
        }
        if (DefaultInstanceObject->HasField(TEXT("bOverrideMass")))
        {
            BodyInstance.bOverrideMass = DefaultInstanceObject->GetBoolField(TEXT("bOverrideMass"));
        }
        if (DefaultInstanceObject->HasField(TEXT("AngularDamping")))
        {
            BodyInstance.AngularDamping = DefaultInstanceObject->GetNumberField(TEXT("AngularDamping"));
        }
        if (DefaultInstanceObject->HasField(TEXT("InertiaTensorScale")))
        {
            BodyInstance.InertiaTensorScale = ReadVector(DefaultInstanceObject, TEXT("InertiaTensorScale"));
        }
        if (DefaultInstanceObject->HasField(TEXT("COMNudge")))
        {
            BodyInstance.COMNudge = ReadVector(DefaultInstanceObject, TEXT("COMNudge"));
        }
    }

    BodySetup->InvalidatePhysicsData();
    BodySetup->CreatePhysicsMeshes();
}

void UPhysicsImporter::DeserializeConstraintTemplate(const TSharedPtr<FJsonObject>& Properties, UPhysicsConstraintTemplate* ConstraintTemplate)
{
    if (!Properties.IsValid() || !ConstraintTemplate)
    {
        return;
    }

    if (Properties->HasField(TEXT("DefaultInstance")))
    {
        DeserializeConstraintInstance(Properties->GetObjectField(TEXT("DefaultInstance")), ConstraintTemplate->DefaultInstance);
    }

    ConstraintTemplate->UpdateProfileInstance();
}

void UPhysicsImporter::DeserializeCollisionDisableTable(const TSharedPtr<FJsonObject>& AssetData, UPhysicsAsset* PhysicsAsset)
{
    if (!AssetData.IsValid() || !PhysicsAsset)
    {
        return;
    }

    const TArray<TSharedPtr<FJsonValue>>* CollisionDisableTable = nullptr;
    if (!AssetData->TryGetArrayField(TEXT("CollisionDisableTable"), CollisionDisableTable))
    {
        const TSharedPtr<FJsonObject>* PropertiesObject = nullptr;
        if (AssetData->TryGetObjectField(TEXT("Properties"), PropertiesObject) && PropertiesObject->IsValid())
        {
            (*PropertiesObject)->TryGetArrayField(TEXT("CollisionDisableTable"), CollisionDisableTable);
        }
    }

    if (!CollisionDisableTable)
    {
        return;
    }

    for (const TSharedPtr<FJsonValue>& TableValue : *CollisionDisableTable)
    {
        const TSharedPtr<FJsonObject> TableObject = TableValue->AsObject();
        if (!TableObject.IsValid())
        {
            continue;
        }

        const bool bDisableCollision = TableObject->GetBoolField(TEXT("Value"));
        const TArray<TSharedPtr<FJsonValue>> Indices = TableObject->GetObjectField(TEXT("Key"))->GetArrayField(TEXT("Indices"));
        if (Indices.Num() < 2)
        {
            continue;
        }

        const int32 BodyIndexA = static_cast<int32>(Indices[0]->AsNumber());
        const int32 BodyIndexB = static_cast<int32>(Indices[1]->AsNumber());
        PhysicsAsset->CollisionDisableTable.Add(FRigidBodyIndexPair(BodyIndexA, BodyIndexB), bDisableCollision);
    }
}

UPhysicsAsset* UPhysicsImporter::ImportPhysicsAsset(
    const FString& JsonString,
    const FString& PackagePath,
    const FString& AssetName,
    const FString& SkeletalMeshPath)
{
    TArray<TSharedPtr<FJsonValue>> ExportsArray;

    TSharedPtr<FJsonObject> RootObject;
    const TSharedRef<TJsonReader<>> ObjectReader = TJsonReaderFactory<>::Create(JsonString);
    if (FJsonSerializer::Deserialize(ObjectReader, RootObject) && RootObject.IsValid())
    {
        if (RootObject->HasField(TEXT("Exports")))
        {
            ExportsArray = RootObject->GetArrayField(TEXT("Exports"));
        }
        else if (RootObject->HasField(TEXT("Type")))
        {
            ExportsArray.Add(MakeShareable(new FJsonValueObject(RootObject)));
        }
    }
    else
    {
        const TSharedRef<TJsonReader<>> ArrayReader = TJsonReaderFactory<>::Create(JsonString);
        FJsonSerializer::Deserialize(ArrayReader, ExportsArray);
    }

    if (ExportsArray.Num() == 0)
    {
        UE_LOG(LogPhysicsImporter, Error, TEXT("No exports found in physics JSON."));
        return nullptr;
    }

    TSharedPtr<FJsonObject> AssetData;
    for (const TSharedPtr<FJsonValue>& ExportValue : ExportsArray)
    {
        const TSharedPtr<FJsonObject> ExportObject = ExportValue->AsObject();
        if (ExportObject.IsValid() && ExportObject->GetStringField(TEXT("Type")) == TEXT("PhysicsAsset"))
        {
            AssetData = ExportObject;
            break;
        }
    }

    if (!AssetData.IsValid())
    {
        UE_LOG(LogPhysicsImporter, Error, TEXT("PhysicsAsset export not found in JSON."));
        return nullptr;
    }

    const FString LongPackagePath = PackagePath / AssetName;
    UPackage* Package = CreatePackage(nullptr, *LongPackagePath);
    if (!Package)
    {
        UE_LOG(LogPhysicsImporter, Error, TEXT("Failed to create package: %s"), *LongPackagePath);
        return nullptr;
    }
    Package->FullyLoad();

    UPhysicsAsset* PhysicsAsset = NewObject<UPhysicsAsset>(Package, UPhysicsAsset::StaticClass(), *AssetName, RF_Public | RF_Standalone);
    if (!PhysicsAsset)
    {
        UE_LOG(LogPhysicsImporter, Error, TEXT("Failed to create physics asset object."));
        return nullptr;
    }

    const TMap<FName, TSharedPtr<FJsonObject>> ExportMap = BuildExportMap(ExportsArray);
    const TSharedPtr<FJsonObject> Properties = AssetData->HasField(TEXT("Properties"))
        ? AssetData->GetObjectField(TEXT("Properties"))
        : AssetData;

    const TArray<TSharedPtr<FJsonValue>>* BodySetupReferences = nullptr;
    if (Properties->TryGetArrayField(TEXT("SkeletalBodySetups"), BodySetupReferences))
    {
        for (const TSharedPtr<FJsonValue>& ReferenceValue : *BodySetupReferences)
        {
            const TSharedPtr<FJsonObject> ReferenceObject = ReferenceValue->AsObject();
            if (!ReferenceObject.IsValid() || !ReferenceObject->HasField(TEXT("ObjectName")))
            {
                continue;
            }

            const FName ExportName = GetExportNameOfSubobject(ReferenceObject->GetStringField(TEXT("ObjectName")));
            const TSharedPtr<FJsonObject>* ExportJson = ExportMap.Find(ExportName);
            if (!ExportJson || !ExportJson->IsValid())
            {
                UE_LOG(LogPhysicsImporter, Warning, TEXT("Missing body setup export: %s"), *ExportName.ToString());
                continue;
            }

            const TSharedPtr<FJsonObject> ExportProperties = (*ExportJson)->GetObjectField(TEXT("Properties"));
            const FName BoneName = FName(*ExportProperties->GetStringField(TEXT("BoneName")));

            USkeletalBodySetup* BodySetup = NewObject<USkeletalBodySetup>(PhysicsAsset, ExportName, RF_Transactional);
            BodySetup->BoneName = BoneName;
            PhysicsAsset->SkeletalBodySetups.Add(BodySetup);
            DeserializeBodySetup(ExportProperties, BodySetup);
        }
    }
    else
    {
        for (const TSharedPtr<FJsonValue>& ExportValue : ExportsArray)
        {
            const TSharedPtr<FJsonObject> ExportObject = ExportValue->AsObject();
            if (!ExportObject.IsValid())
            {
                continue;
            }

            bool bIsBodySetup = false;
            if (ExportObject->HasField(TEXT("Type")))
            {
                bIsBodySetup = ExportObject->GetStringField(TEXT("Type")).Contains(TEXT("SkeletalBodySetup"));
            }
            else if (ExportObject->HasField(TEXT("Class")))
            {
                bIsBodySetup = ExportObject->GetStringField(TEXT("Class")).Contains(TEXT("SkeletalBodySetup"));
            }

            if (!bIsBodySetup || !ExportObject->HasField(TEXT("Properties")))
            {
                continue;
            }

            const TSharedPtr<FJsonObject> ExportProperties = ExportObject->GetObjectField(TEXT("Properties"));
            const FName ExportName = ExportObject->HasField(TEXT("Name"))
                ? FName(*ExportObject->GetStringField(TEXT("Name")))
                : FName(TEXT("SkeletalBodySetup"));
            const FName BoneName = FName(*ExportProperties->GetStringField(TEXT("BoneName")));

            USkeletalBodySetup* BodySetup = NewObject<USkeletalBodySetup>(PhysicsAsset, ExportName, RF_Transactional);
            BodySetup->BoneName = BoneName;
            PhysicsAsset->SkeletalBodySetups.Add(BodySetup);
            DeserializeBodySetup(ExportProperties, BodySetup);
        }
    }

    PhysicsAsset->UpdateBodySetupIndexMap();
    PhysicsAsset->UpdateBoundsBodiesArray();
    DeserializeCollisionDisableTable(AssetData, PhysicsAsset);

    const TArray<TSharedPtr<FJsonValue>>* ConstraintReferences = nullptr;
    if (Properties->TryGetArrayField(TEXT("ConstraintSetup"), ConstraintReferences))
    {
        for (const TSharedPtr<FJsonValue>& ReferenceValue : *ConstraintReferences)
        {
            const TSharedPtr<FJsonObject> ReferenceObject = ReferenceValue->AsObject();
            if (!ReferenceObject.IsValid() || !ReferenceObject->HasField(TEXT("ObjectName")))
            {
                continue;
            }

            const FName ExportName = GetExportNameOfSubobject(ReferenceObject->GetStringField(TEXT("ObjectName")));
            const TSharedPtr<FJsonObject>* ExportJson = ExportMap.Find(ExportName);
            if (!ExportJson || !ExportJson->IsValid())
            {
                UE_LOG(LogPhysicsImporter, Warning, TEXT("Missing constraint export: %s"), *ExportName.ToString());
                continue;
            }

            UPhysicsConstraintTemplate* ConstraintTemplate = NewObject<UPhysicsConstraintTemplate>(PhysicsAsset, ExportName, RF_Transactional);
            PhysicsAsset->ConstraintSetup.Add(ConstraintTemplate);
            DeserializeConstraintTemplate((*ExportJson)->GetObjectField(TEXT("Properties")), ConstraintTemplate);
        }
    }
    else
    {
        for (const TSharedPtr<FJsonValue>& ExportValue : ExportsArray)
        {
            const TSharedPtr<FJsonObject> ExportObject = ExportValue->AsObject();
            if (!ExportObject.IsValid())
            {
                continue;
            }

            bool bIsConstraint = false;
            if (ExportObject->HasField(TEXT("Type")))
            {
                bIsConstraint = ExportObject->GetStringField(TEXT("Type")).Contains(TEXT("PhysicsConstraintTemplate"));
            }
            else if (ExportObject->HasField(TEXT("Class")))
            {
                bIsConstraint = ExportObject->GetStringField(TEXT("Class")).Contains(TEXT("PhysicsConstraintTemplate"));
            }

            if (!bIsConstraint || !ExportObject->HasField(TEXT("Properties")))
            {
                continue;
            }

            const FName ExportName = ExportObject->HasField(TEXT("Name"))
                ? FName(*ExportObject->GetStringField(TEXT("Name")))
                : FName(TEXT("PhysicsConstraintTemplate"));

            UPhysicsConstraintTemplate* ConstraintTemplate = NewObject<UPhysicsConstraintTemplate>(PhysicsAsset, ExportName, RF_Transactional);
            PhysicsAsset->ConstraintSetup.Add(ConstraintTemplate);
            DeserializeConstraintTemplate(ExportObject->GetObjectField(TEXT("Properties")), ConstraintTemplate);
        }
    }

    const TArray<TSharedPtr<FJsonValue>>* BoundsBodies = nullptr;
    if (Properties->TryGetArrayField(TEXT("BoundsBodies"), BoundsBodies))
    {
        PhysicsAsset->BoundsBodies.Empty();
        for (const TSharedPtr<FJsonValue>& BoundsBodyValue : *BoundsBodies)
        {
            PhysicsAsset->BoundsBodies.Add(static_cast<int32>(BoundsBodyValue->AsNumber()));
        }
    }

    PhysicsAsset->UpdateBoundsBodiesArray();

    FString MeshPath = SkeletalMeshPath;
    if (MeshPath.IsEmpty())
    {
        FString CleanName = AssetName;
        CleanName.RemoveFromEnd(TEXT("_PhysicsAsset"));
        CleanName.RemoveFromEnd(TEXT("_Physics"));
        MeshPath = FString::Printf(TEXT("%s/%s.%s"), *PackagePath, *CleanName, *CleanName);
    }
    else if (!MeshPath.Contains(TEXT(".")))
    {
        const FString MeshName = FPackageName::GetLongPackageAssetName(MeshPath);
        MeshPath = FString::Printf(TEXT("%s.%s"), *MeshPath, *MeshName);
    }

    if (USkeletalMesh* SkeletalMesh = Cast<USkeletalMesh>(StaticLoadObject(USkeletalMesh::StaticClass(), nullptr, *MeshPath)))
    {
        PhysicsAsset->PreviewSkeletalMesh = SkeletalMesh;
        UE_LOG(LogPhysicsImporter, Log, TEXT("Linked physics asset to skeletal mesh: %s"), *MeshPath);
    }
    else
    {
        UE_LOG(LogPhysicsImporter, Warning, TEXT("Could not load skeletal mesh at: %s"), *MeshPath);
    }

    PhysicsAsset->Modify();
    FAssetRegistryModule::AssetCreated(PhysicsAsset);
    Package->MarkPackageDirty();
    PhysicsAsset->PostEditChange();

    UE_LOG(LogPhysicsImporter, Log, TEXT("Imported physics asset '%s' with %d bodies and %d constraints."),
        *AssetName,
        PhysicsAsset->SkeletalBodySetups.Num(),
        PhysicsAsset->ConstraintSetup.Num());

    return PhysicsAsset;
}

namespace
{
    bool FindCopyPoseAndRootPins(
        UEdGraph* AnimGraph,
        UAnimGraphNode_CopyPoseFromMesh*& OutCopyPoseNode,
        UEdGraphPin*& OutSourcePin,
        UEdGraphPin*& OutTargetPin,
        const TCHAR* LogContext)
    {
        OutCopyPoseNode = nullptr;
        UAnimGraphNode_Root* RootNode = nullptr;

        for (UEdGraphNode* Node : AnimGraph->Nodes)
        {
            if (!OutCopyPoseNode)
            {
                OutCopyPoseNode = Cast<UAnimGraphNode_CopyPoseFromMesh>(Node);
            }
            if (!RootNode)
            {
                RootNode = Cast<UAnimGraphNode_Root>(Node);
            }
        }

        if (!OutCopyPoseNode || !RootNode)
        {
            UE_LOG(LogPhysicsImporter, Error, TEXT("%s: Template graph missing CopyPoseFromMesh or Output Pose node."), LogContext);
            return false;
        }

        OutSourcePin = FindPosePin(OutCopyPoseNode, EGPD_Output);
        OutTargetPin = FindPosePin(RootNode, EGPD_Input);

        if (!OutSourcePin || !OutTargetPin)
        {
            UE_LOG(LogPhysicsImporter, Error, TEXT("%s: Could not resolve pose pins on CopyPoseFromMesh/Output."), LogContext);
            return false;
        }

        return true;
    }
}

UAnimBlueprint* UPhysicsImporter::CreateAnimBlueprint(const FString& PackagePath, const FString& AssetName, USkeleton* Skeleton)
{
    if (!Skeleton)
    {
        UE_LOG(LogPhysicsImporter, Error, TEXT("CreateAnimBlueprint: Skeleton is null."));
        return nullptr;
    }

    const FString PackageName = UPackageTools::SanitizePackageName(FPaths::Combine(PackagePath, AssetName));

    if (UEditorAssetLibrary::DoesAssetExist(PackageName))
    {
        UEditorAssetLibrary::DeleteAsset(PackageName);
    }

    UPackage* Package = CreatePackage(nullptr, *PackageName);
    if (!Package)
    {
        UE_LOG(LogPhysicsImporter, Error, TEXT("CreateAnimBlueprint: Could not create package '%s'."), *PackageName);
        return nullptr;
    }

    UAnimBlueprintFactory* Factory = NewObject<UAnimBlueprintFactory>();
    Factory->ParentClass = UAnimInstance::StaticClass();
    Factory->TargetSkeleton = Skeleton;

    UAnimBlueprint* AnimBlueprint = Cast<UAnimBlueprint>(Factory->FactoryCreateNew(
        UAnimBlueprint::StaticClass(),
        Package,
        FName(*AssetName),
        RF_Public | RF_Standalone | RF_Transactional,
        nullptr,
        GWarn));

    if (!AnimBlueprint)
    {
        UE_LOG(LogPhysicsImporter, Error, TEXT("CreateAnimBlueprint: Factory failed to create AnimBlueprint '%s'."), *AssetName);
        return nullptr;
    }

    UEdGraph* AnimGraph = FindAnimGraph(AnimBlueprint);
    if (!AnimGraph)
    {
        UE_LOG(LogPhysicsImporter, Error, TEXT("CreateAnimBlueprint: New AnimBlueprint '%s' has no AnimGraph."), *AssetName);
        return nullptr;
    }

    FGraphNodeCreator<UAnimGraphNode_CopyPoseFromMesh> CopyPoseCreator(*AnimGraph);
    UAnimGraphNode_CopyPoseFromMesh* CopyPoseNode = CopyPoseCreator.CreateNode();
    CopyPoseNode->NodePosX = 0;
    CopyPoseNode->NodePosY = 0;
    CopyPoseNode->Node.bUseAttachedParent = true;
    CopyPoseCreator.Finalize();

    FBlueprintEditorUtils::MarkBlueprintAsModified(AnimBlueprint);
    FKismetEditorUtilities::CompileBlueprint(AnimBlueprint);

    FAssetRegistryModule::AssetCreated(AnimBlueprint);
    Package->MarkPackageDirty();

    UE_LOG(LogPhysicsImporter, Log, TEXT("CreateAnimBlueprint: Created '%s' targeting skeleton '%s'."),
        *PackageName, *Skeleton->GetName());

    return AnimBlueprint;
}

bool UPhysicsImporter::BuildCopyPoseAnimGraph(UAnimBlueprint* AnimBlueprint)
{
    if (!AnimBlueprint)
    {
        UE_LOG(LogPhysicsImporter, Error, TEXT("BuildCopyPoseAnimGraph: AnimBlueprint is null."));
        return false;
    }

    UEdGraph* AnimGraph = FindAnimGraph(AnimBlueprint);
    if (!AnimGraph)
    {
        UE_LOG(LogPhysicsImporter, Error, TEXT("BuildCopyPoseAnimGraph: No AnimGraph found in '%s'."), *AnimBlueprint->GetName());
        return false;
    }

    UAnimGraphNode_CopyPoseFromMesh* CopyPoseNode = nullptr;
    UEdGraphPin* SourcePin = nullptr;
    UEdGraphPin* TargetPin = nullptr;

    if (!FindCopyPoseAndRootPins(AnimGraph, CopyPoseNode, SourcePin, TargetPin, TEXT("BuildCopyPoseAnimGraph")))
    {
        return false;
    }

    TargetPin->BreakAllPinLinks();
    SourcePin->MakeLinkTo(TargetPin);

    FBlueprintEditorUtils::MarkBlueprintAsModified(AnimBlueprint);
    FKismetEditorUtilities::CompileBlueprint(AnimBlueprint);

    UE_LOG(LogPhysicsImporter, Log, TEXT("BuildCopyPoseAnimGraph: Wired CopyPoseFromMesh directly to output pose in '%s'."),
        *AnimBlueprint->GetName());

    return true;
}

bool UPhysicsImporter::BuildRigidBodyAnimGraph(UAnimBlueprint* AnimBlueprint, const TArray<UPhysicsAsset*>& PhysicsAssets)
{
    if (!AnimBlueprint)
    {
        UE_LOG(LogPhysicsImporter, Error, TEXT("BuildRigidBodyAnimGraph: AnimBlueprint is null."));
        return false;
    }

    UEdGraph* AnimGraph = FindAnimGraph(AnimBlueprint);
    if (!AnimGraph)
    {
        UE_LOG(LogPhysicsImporter, Error, TEXT("BuildRigidBodyAnimGraph: No AnimGraph found in '%s'."), *AnimBlueprint->GetName());
        return false;
    }

    UAnimGraphNode_CopyPoseFromMesh* CopyPoseNode = nullptr;
    UEdGraphPin* SourcePin = nullptr;
    UEdGraphPin* TargetPin = nullptr;

    if (!FindCopyPoseAndRootPins(AnimGraph, CopyPoseNode, SourcePin, TargetPin, TEXT("BuildRigidBodyAnimGraph")))
    {
        return false;
    }

    TargetPin->BreakAllPinLinks();

    FGraphNodeCreator<UAnimGraphNode_LocalToComponentSpace> L2CCreator(*AnimGraph);
    UAnimGraphNode_LocalToComponentSpace* L2CNode = L2CCreator.CreateNode();
    L2CNode->NodePosX = CopyPoseNode->NodePosX + 250;
    L2CNode->NodePosY = CopyPoseNode->NodePosY;
    L2CCreator.Finalize();

    UEdGraphPin* L2CInput = FindPosePin(L2CNode, EGPD_Input);
    UEdGraphPin* L2COutput = FindPosePin(L2CNode, EGPD_Output);

    if (!L2CInput || !L2COutput)
    {
        UE_LOG(LogPhysicsImporter, Error, TEXT("BuildRigidBodyAnimGraph: Could not resolve pose pins on LocalToComponent."));
        return false;
    }

    SourcePin->MakeLinkTo(L2CInput);

    UEdGraphPin* ChainOutput = L2COutput;
    int32 XOffset = 500;

    for (UPhysicsAsset* PhysAsset : PhysicsAssets)
    {
        FGraphNodeCreator<UAnimGraphNode_RigidBody> RBCreator(*AnimGraph);
        UAnimGraphNode_RigidBody* RBNode = RBCreator.CreateNode();
        RBNode->NodePosX = CopyPoseNode->NodePosX + XOffset;
        RBNode->NodePosY = CopyPoseNode->NodePosY;
        RBCreator.Finalize();

        RBNode->Node.OverridePhysicsAsset = PhysAsset;

        UEdGraphPin* RBInput = FindPosePin(RBNode, EGPD_Input);
        UEdGraphPin* RBOutput = FindPosePin(RBNode, EGPD_Output);

        if (!RBInput || !RBOutput)
        {
            UE_LOG(LogPhysicsImporter, Error, TEXT("BuildRigidBodyAnimGraph: Could not resolve pose pins on RigidBody node."));
            return false;
        }

        ChainOutput->MakeLinkTo(RBInput);
        ChainOutput = RBOutput;

        XOffset += 250;
    }

    FGraphNodeCreator<UAnimGraphNode_ComponentToLocalSpace> C2LCreator(*AnimGraph);
    UAnimGraphNode_ComponentToLocalSpace* C2LNode = C2LCreator.CreateNode();
    C2LNode->NodePosX = CopyPoseNode->NodePosX + XOffset;
    C2LNode->NodePosY = CopyPoseNode->NodePosY;
    C2LCreator.Finalize();

    UEdGraphPin* C2LInput = FindPosePin(C2LNode, EGPD_Input);
    UEdGraphPin* C2LOutput = FindPosePin(C2LNode, EGPD_Output);

    if (!C2LInput || !C2LOutput)
    {
        UE_LOG(LogPhysicsImporter, Error, TEXT("BuildRigidBodyAnimGraph: Could not resolve pose pins on ComponentToLocal."));
        return false;
    }

    ChainOutput->MakeLinkTo(C2LInput);
    C2LOutput->MakeLinkTo(TargetPin);

    FBlueprintEditorUtils::MarkBlueprintAsModified(AnimBlueprint);
    FKismetEditorUtilities::CompileBlueprint(AnimBlueprint);

    UE_LOG(LogPhysicsImporter, Log, TEXT("BuildRigidBodyAnimGraph: Built RigidBody chain with %d physics asset(s) in '%s'."),
        PhysicsAssets.Num(), *AnimBlueprint->GetName());

    return true;
}

bool UPhysicsImporter::BuildAnimGraph(UAnimBlueprint* AnimBlueprint, const TArray<UPhysicsAsset*>& PhysicsAssets)
{
    if (PhysicsAssets.Num() == 0)
    {
        return UPhysicsImporter::BuildCopyPoseAnimGraph(AnimBlueprint);
    }

    return UPhysicsImporter::BuildRigidBodyAnimGraph(AnimBlueprint, PhysicsAssets);
}