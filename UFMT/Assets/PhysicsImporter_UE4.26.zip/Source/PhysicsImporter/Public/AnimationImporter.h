#pragma once

#include "Core.h"
#include "Dom/JsonObject.h"
#include "Animation/AnimSequence.h"
#include "Animation/Skeleton.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "AnimationImporter.generated.h"

UCLASS(BlueprintType)
class UAnimationImporter : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Animation")
    static bool ImportAnimationSequence(const FString& JsonString, const FString& AnimSequencePath);

private:
    static void SetAnimSequenceLength(UAnimSequence* AnimSequence, float NewLength);
    static void ImportFloatCurves(const TSharedPtr<FJsonObject>& Properties, const TSharedPtr<FJsonObject>& AssetExport, UAnimSequence* AnimSequence);
};